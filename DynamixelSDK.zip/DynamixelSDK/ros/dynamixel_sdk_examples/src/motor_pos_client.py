#!/usr/bin/env python3
 
import time
import rospy
from dynamixel_sdk_examples.srv import *
from dynamixel_sdk_examples.msg import *

m1_range = [1025, 3030]

    
def read_motor_pos():
    #declare ServiceProxy to read the motor position
    rospy.wait_for_service('get_position')
    motor_pos = rospy.ServiceProxy('get_position', GetPosition)
    try:
        # print('attempting to read motors')        
        return [motor_pos(0).position, motor_pos(1).position, motor_pos(2).position]
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

if __name__ == "__main__":
    #declare publisher to write motor position
    rospy.init_node('motor_pos_writer')
    motor_writer = rospy.Publisher('set_position', SetPosition, queue_size=10)
    target_pos = SetPosition()
    print('MotorWriter Initialized...')
    rate = rospy.Rate(10)

    positions = list()
    n = 100

    tic = time.perf_counter()
    for i in range(n):
        #save current position
        positions.append(read_motor_pos())
        print(positions[i])

        #move to new position
        for (m_id,m_pos) in enumerate(positions[i]):
            target_pos.id = m_id
            target_pos.position = m_pos+20
            print(f'{target_pos}')

            #check if motor is within its range of motion
            if target_pos.position < m1_range[0] or target_pos.position > m1_range[1]:
                #reset to middle of range of motion if out of bound
                target_pos.position = 1025

            motor_writer.publish(target_pos)
        
        rate.sleep()


    toc = time.perf_counter()
    print(f"Motor Pos Sampling Rate: {n/(toc - tic):0.4f} Hz")
    # print(positions)



# rostopic pub command for reference
# rostopic pub -1 /set_position dynamixel_sdk_examples/SetPosition "{id:1, position: 0}"